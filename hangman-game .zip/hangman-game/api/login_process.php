<?php
// Start session
session_start();

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Create log file for debugging
$log_file = dirname(__FILE__) . '/login_log.txt';
file_put_contents($log_file, "=== " . date('Y-m-d H:i:s') . " === New Login Request ===\n", FILE_APPEND);
file_put_contents($log_file, "Request Method: " . $_SERVER['REQUEST_METHOD'] . "\n", FILE_APPEND);

// Include database connection
try {
    require_once 'db_connection.php';
    file_put_contents($log_file, "Database connection file included\n", FILE_APPEND);
} catch (Exception $e) {
    file_put_contents($log_file, "Error loading database connection: " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode([
        'success' => false,
        'message' => 'Database connection error: ' . $e->getMessage()
    ]);
    exit;
}

// Check if connection variable exists
if (!isset($conn)) {
    file_put_contents($log_file, "Error: Database connection variable not found\n", FILE_APPEND);
    echo json_encode([
        'success' => false,
        'message' => 'Database connection error'
    ]);
    exit;
}

// Handle login logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    file_put_contents($log_file, "POST Data: " . print_r($_POST, true) . "\n", FILE_APPEND);
    
    // Get input data
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    // Validate input
    if (empty($username) || empty($password)) {
        file_put_contents($log_file, "Error: Empty username or password\n", FILE_APPEND);
        echo json_encode([
            'success' => false,
            'message' => 'Username dan password harus diisi'
        ]);
        exit;
    }
    
    try {
        // Check if users table exists first
        $tables = $conn->query("SHOW TABLES LIKE 'users'");
        if ($tables->num_rows === 0) {
            file_put_contents($log_file, "Error: Users table not found in database\n", FILE_APPEND);
            echo json_encode([
                'success' => false,
                'message' => 'Kesalahan sistem: Tabel users tidak ditemukan'
            ]);
            exit;
        }
        
        // Prepare statement to prevent SQL injection
        $stmt = $conn->prepare("SELECT user_id, username, password FROM users WHERE username = ?");
        if (!$stmt) {
            file_put_contents($log_file, "Error: " . $conn->error . "\n", FILE_APPEND);
            echo json_encode([
                'success' => false,
                'message' => 'Database query error'
            ]);
            exit;
        }
        
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            file_put_contents($log_file, "Error: User not found: $username\n", FILE_APPEND);
            echo json_encode([
                'success' => false,
                'message' => 'Username atau password salah'
            ]);
            exit;
        }
        
        // Get user data
        $user = $result->fetch_assoc();
        
        // Verify password (assuming it's stored in plain text based on your schema)
        // In a production environment, you should use password hashing
        if ($password === $user['password']) {
            // Login successful, set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['logged_in'] = true;
            
            // Update last login time
            $updateStmt = $conn->prepare("UPDATE users SET last_login = UNIX_TIMESTAMP() WHERE user_id = ?");
            $updateStmt->bind_param("i", $user['user_id']);
            $updateStmt->execute();
            
            file_put_contents($log_file, "Success: User $username logged in\n", FILE_APPEND);
            echo json_encode([
                'success' => true,
                'message' => 'Login berhasil',
                'user' => [
                    'user_id' => $user['user_id'],
                    'username' => $user['username']
                ]
            ]);
        } else {
            file_put_contents($log_file, "Error: Password mismatch for user: $username\n", FILE_APPEND);
            echo json_encode([
                'success' => false,
                'message' => 'Username atau password salah'
            ]);
        }
    } catch (Exception $e) {
        file_put_contents($log_file, "Error: " . $e->getMessage() . "\n", FILE_APPEND);
        echo json_encode([
            'success' => false,
            'message' => 'Error saat login: ' . $e->getMessage()
        ]);
    }
} else {
    // If not a POST request
    file_put_contents($log_file, "Error: Invalid request method: " . $_SERVER['REQUEST_METHOD'] . "\n", FILE_APPEND);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
?>