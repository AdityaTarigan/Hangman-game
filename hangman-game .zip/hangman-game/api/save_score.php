<?php
// Start session
session_start();

// Set timezone to Indonesia/Jakarta
date_default_timezone_set('Asia/Jakarta');

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include database connection
require_once 'db_connection.php';

// Create log file for debugging
$log_file = 'save_score_log.txt';
file_put_contents($log_file, "=== " . date('Y-m-d H:i:s') . " === New Score Save Request ===\n", FILE_APPEND);
file_put_contents($log_file, "POST Data: " . print_r($_POST, true) . "\n", FILE_APPEND);
file_put_contents($log_file, "Session Data: " . print_r($_SESSION, true) . "\n", FILE_APPEND);
file_put_contents($log_file, "Cookie Data: " . print_r($_COOKIE, true) . "\n", FILE_APPEND);
file_put_contents($log_file, "Request Headers: " . print_r(getallheaders(), true) . "\n", FILE_APPEND);
file_put_contents($log_file, "Server Variables: " . print_r($_SERVER, true) . "\n", FILE_APPEND);

// Set content type and CORS headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    file_put_contents($log_file, "Error: Invalid request method: " . $_SERVER['REQUEST_METHOD'] . "\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Check if user is logged in
$is_logged_in = isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
file_put_contents($log_file, "User login status: " . ($is_logged_in ? "Logged in" : "Not logged in") . "\n", FILE_APPEND);
file_put_contents($log_file, "Session ID: " . session_id() . "\n", FILE_APPEND);

if (!$is_logged_in) {
    file_put_contents($log_file, "Login required, returning appropriate response\n", FILE_APPEND);
    echo json_encode([
        'success' => false,
        'message' => 'Login required to save score',
        'loginRequired' => true,
        'redirect' => 'login.html'
    ]);
    exit;
}

// Check for required fields
$required_fields = ['score', 'incorrect_guesses', 'time_spent', 'difficulty'];
foreach ($required_fields as $field) {
    if (!isset($_POST[$field]) || trim($_POST[$field]) === '') {
        file_put_contents($log_file, "Error: Missing required field: $field\n", FILE_APPEND);
        echo json_encode(['success' => false, 'message' => "Missing required field: $field"]);
        exit;
    }
}

try {
    // Get and sanitize input data
    $score = intval($_POST['score']);
    $incorrect_guesses = intval($_POST['incorrect_guesses']);
    $hints_used = isset($_POST['hints_used']) ? intval($_POST['hints_used']) : 0;
    $time_spent = intval($_POST['time_spent']);
    $word_length = isset($_POST['word_length']) ? intval($_POST['word_length']) : 0;
    $difficulty = $conn->real_escape_string($_POST['difficulty']);
    
    // Get user data from session
    $user_id = $_SESSION['user_id'];
    $username = $_SESSION['username'];
    
    file_put_contents($log_file, "Processed data: user_id=$user_id, username=$username, score=$score, incorrect=$incorrect_guesses, time=$time_spent\n", FILE_APPEND);
    
    // Convert difficulty string to level
    $difficulty_level = 2; // Default to medium
    switch ($difficulty) {
        case 'easy': $difficulty_level = 1; break;
        case 'medium': $difficulty_level = 2; break;
        case 'hard': $difficulty_level = 3; break;
        case 'expert': $difficulty_level = 4; break;
    }
    
    // Begin transaction
    $conn->begin_transaction();
    
    // Find or create game entry
    $gameQuery = "SELECT game_id FROM games WHERE game_code = 'hangman'";
    $gameResult = $conn->query($gameQuery);
    
    if ($gameResult && $gameResult->num_rows > 0) {
        $gameRow = $gameResult->fetch_assoc();
        $game_id = $gameRow['game_id'];
        file_put_contents($log_file, "Found existing game_id: $game_id\n", FILE_APPEND);
    } else {
        // Create hangman game entry - menggunakan variabel timestamp untuk created_at
        $currentTimestamp = time();
        $insertGameSql = "INSERT INTO games (game_name, game_code, description, created_at) 
                         VALUES ('Hangman', 'hangman', 'Word guessing game', ?)";
        $gameStmt = $conn->prepare($insertGameSql);
        if (!$gameStmt) {
            throw new Exception("Error preparing game insert: " . $conn->error);
        }
        $gameStmt->bind_param("i", $currentTimestamp);
        if (!$gameStmt->execute()) {
            throw new Exception("Error creating game: " . $gameStmt->error);
        }
        $game_id = $conn->insert_id;
        $gameStmt->close();
        file_put_contents($log_file, "Created new game with ID: $game_id\n", FILE_APPEND);
    }
    
    // Insert into scores table - menggunakan variabel timestamp dengan zona waktu yang benar
    $currentTimestamp = time();
    $scoreSql = "INSERT INTO scores (user_id, game_id, score, timestamp) VALUES (?, ?, ?, ?)";
    $scoreStmt = $conn->prepare($scoreSql);
    
    if (!$scoreStmt) {
        throw new Exception("Error preparing score insert: " . $conn->error);
    }
    
    $scoreStmt->bind_param("iiii", $user_id, $game_id, $score, $currentTimestamp);
    
    if (!$scoreStmt->execute()) {
        throw new Exception("Error inserting score: " . $scoreStmt->error);
    }
    
    $score_id = $conn->insert_id;
    $scoreStmt->close();
    file_put_contents($log_file, "Inserted score with ID: $score_id (timestamp: $currentTimestamp - " . date('Y-m-d H:i:s', $currentTimestamp) . ")\n", FILE_APPEND);
    
    // Calculate remaining tries
    $remaining_tries = 7 - $incorrect_guesses;
    
    // Insert into hangman_scores table
    $hangmanSql = "INSERT INTO hangman_scores 
                  (score_id, word_length, wrong_guesses, remaining_tries, difficulty_level, time_spent, word_category) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
    $hangmanStmt = $conn->prepare($hangmanSql);
    
    if (!$hangmanStmt) {
        throw new Exception("Error preparing hangman score insert: " . $conn->error);
    }
    
    $word_category = "Bandung"; // Default word category
    
    $hangmanStmt->bind_param("iiiiiss", 
        $score_id, 
        $word_length, 
        $incorrect_guesses, 
        $remaining_tries, 
        $difficulty_level, 
        $time_spent, 
        $word_category
    );
    
    if (!$hangmanStmt->execute()) {
        throw new Exception("Error inserting hangman score: " . $hangmanStmt->error);
    }
    
    $hangmanStmt->close();
    
    // Commit transaction
    $conn->commit();
    
    file_put_contents($log_file, "SUCCESS: Score saved completely\n", FILE_APPEND);
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Score saved successfully',
        'score_id' => $score_id,
        'user_id' => $user_id,
        'score' => $score
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    
    file_put_contents($log_file, "ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode([
        'success' => false,
        'message' => 'Error saving score: ' . $e->getMessage()
    ]);
}

// Close database connection
$conn->close();