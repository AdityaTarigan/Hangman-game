<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include database connection
require_once 'db_connection.php';

// Handle CORS if needed
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

// Find game_id for Hangman
$gameIdQuery = "SELECT game_id FROM games WHERE game_code = 'hangman'";
$gameResult = mysqli_query($conn, $gameIdQuery);

if (!$gameResult) {
    echo json_encode([
        'success' => false,
        'message' => 'Error querying games table: ' . mysqli_error($conn)
    ]);
    exit;
}

if ($gameRow = mysqli_fetch_assoc($gameResult)) {
    $gameId = $gameRow['game_id'];
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Hangman game not found in database'
    ]);
    exit;
}

// Get stats for the game
$stats = [];

// Get total unique players
$sql = "SELECT COUNT(DISTINCT user_id) as total_players FROM scores WHERE game_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $gameId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && $row = mysqli_fetch_assoc($result)) {
    $stats['totalPlayers'] = intval($row['total_players']);
} else {
    $stats['totalPlayers'] = 0;
}

// Get total games played
$sql = "SELECT COUNT(*) as games_played FROM scores WHERE game_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $gameId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && $row = mysqli_fetch_assoc($result)) {
    $stats['gamesPlayed'] = intval($row['games_played']);
} else {
    $stats['gamesPlayed'] = 0;
}

// Get highest score
$sql = "SELECT MAX(score) as highest_score FROM scores WHERE game_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $gameId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && $row = mysqli_fetch_assoc($result)) {
    $stats['highestScore'] = intval($row['highest_score']);
} else {
    $stats['highestScore'] = 0;
}

// Get average score
$sql = "SELECT AVG(score) as avg_score FROM scores WHERE game_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $gameId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && $row = mysqli_fetch_assoc($result)) {
    $stats['averageScore'] = round(floatval($row['avg_score']), 2);
} else {
    $stats['averageScore'] = 0;
}

// Get stats by difficulty
$sql = "SELECT 
            h.difficulty_level, 
            COUNT(*) as games_count, 
            AVG(s.score) as avg_score,
            MAX(s.score) as max_score
        FROM scores s
        JOIN hangman_scores h ON s.score_id = h.score_id
        WHERE s.game_id = ?
        GROUP BY h.difficulty_level";
        
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $gameId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    $stats['byDifficulty'] = [
        'easy' => ['count' => 0, 'avgScore' => 0, 'maxScore' => 0],
        'medium' => ['count' => 0, 'avgScore' => 0, 'maxScore' => 0],
        'hard' => ['count' => 0, 'avgScore' => 0, 'maxScore' => 0],
        'expert' => ['count' => 0, 'avgScore' => 0, 'maxScore' => 0]
    ];
    
    while ($row = mysqli_fetch_assoc($result)) {
        // Map difficulty level ID to string
        $difficultyString = 'medium';
        switch ($row['difficulty_level']) {
            case 1: $difficultyString = 'easy'; break;
            case 2: $difficultyString = 'medium'; break;
            case 3: $difficultyString = 'hard'; break;
            case 4: $difficultyString = 'expert'; break;
        }
        
        $stats['byDifficulty'][$difficultyString] = [
            'count' => intval($row['games_count']),
            'avgScore' => round(floatval($row['avg_score']), 2),
            'maxScore' => intval($row['max_score'])
        ];
    }
}

// Return the stats data
echo json_encode([
    'success' => true,
    'stats' => $stats
]);

// Close database connection
mysqli_close($conn);
?>