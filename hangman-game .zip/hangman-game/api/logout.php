<?php
// Start session
session_start();

// Create log file for debugging
$log_file = 'logout_log.txt';
file_put_contents($log_file, "=== " . date('Y-m-d H:i:s') . " === Logout Attempt ===\n", FILE_APPEND);

// Log who is logging out
if (isset($_SESSION['user_id']) && isset($_SESSION['username'])) {
    file_put_contents($log_file, "User " . $_SESSION['username'] . " (ID: " . $_SESSION['user_id'] . ") logged out\n", FILE_APPEND);
} else {
    file_put_contents($log_file, "Logout attempted with no active session\n", FILE_APPEND);
}

// Unset all session variables
$_SESSION = array();

// Delete the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy the session
session_destroy();

// Redirect to login page or home page
$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : '/hangman-game/index.html';
header("Location: $redirect");
exit;
?>