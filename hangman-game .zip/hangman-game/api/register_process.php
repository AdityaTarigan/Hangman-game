<?php
// Start session
session_start();

// Enable error logging instead of displaying
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'register_error.log');

// Set header to JSON
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Include database connection
require_once 'db_connection.php';

// Log request
$log_file = 'register_debug.txt';
file_put_contents($log_file, "=== " . date('Y-m-d H:i:s') . " === New Registration Attempt ===\n", FILE_APPEND);
file_put_contents($log_file, "POST Data: " . print_r($_POST, true) . "\n", FILE_APPEND);

try {
    // Check if request is POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method");
    }
    
    // Get form data
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirmPassword = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    
    // Validate inputs
    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        throw new Exception("Semua kolom harus diisi");
    }
    
    if (strlen($username) < 3) {
        throw new Exception("Username harus minimal 3 karakter");
    }
    
    if (strlen($password) < 6) {
        throw new Exception("Password harus minimal 6 karakter");
    }
    
    if ($password !== $confirmPassword) {
        throw new Exception("Password dan konfirmasi password tidak cocok");
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Format email tidak valid");
    }
    
    // Check if username exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
    if (!$stmt) {
        throw new Exception("Database error: " . $conn->error);
    }
    
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        throw new Exception("Username sudah digunakan, silakan pilih username lain");
    }
    
    $stmt->close();
    
    // Check if email exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    if (!$stmt) {
        throw new Exception("Database error: " . $conn->error);
    }
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        throw new Exception("Email sudah terdaftar, silakan gunakan email lain");
    }
    
    $stmt->close();
    
    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, UNIX_TIMESTAMP())");
    if (!$stmt) {
        throw new Exception("Database error: " . $conn->error);
    }
    
    $stmt->bind_param("sss", $username, $email, $password);
    
    if (!$stmt->execute()) {
        throw new Exception("Error saat membuat user baru: " . $stmt->error);
    }
    
    $userId = $conn->insert_id;
    
    // Success
    echo json_encode([
        'success' => true,
        'message' => 'Pendaftaran berhasil! Silakan login dengan akun baru Anda.',
        'user_id' => $userId
    ]);
    
} catch (Exception $e) {
    // Log the error
    file_put_contents($log_file, "ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
    
    // Send error response
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

// Close connection
$conn->close();
?>