<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set timezone to Indonesia/Jakarta
date_default_timezone_set('Asia/Jakarta');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
require_once 'db_connection.php';

// Set content type to JSON
header('Content-Type: application/json');

// Log file for debugging
$log_file = 'leaderboard_debug.txt';
file_put_contents($log_file, "=== " . date('Y-m-d H:i:s') . " === Leaderboard Request ===\n", FILE_APPEND);
file_put_contents($log_file, "GET Data: " . print_r($_GET, true) . "\n", FILE_APPEND);

// Process difficulty filter
$difficulty = isset($_GET['difficulty']) ? $_GET['difficulty'] : 'all';
$timeFilter = isset($_GET['timeFilter']) ? $_GET['timeFilter'] : 'allTime';

file_put_contents($log_file, "Filters: difficulty=$difficulty, timeFilter=$timeFilter\n", FILE_APPEND);

try {
    // Modified query to get best score per user and difficulty
    // We'll use a subquery to find the highest score for each user in each difficulty level
    $query = "
        WITH BestScores AS (
            SELECT 
                u.user_id,
                u.username,
                hs.difficulty_level,
                MAX(s.score) as max_score
            FROM 
                scores s
            JOIN 
                users u ON s.user_id = u.user_id
            JOIN 
                hangman_scores hs ON s.score_id = hs.score_id
            JOIN 
                games g ON s.game_id = g.game_id
            WHERE 
                g.game_code = 'hangman'
    ";

    // Add time filter to the subquery
    $currentTime = time();
    if ($timeFilter !== 'allTime') {
        switch ($timeFilter) {
            case 'today':
                $startTime = strtotime('today midnight');
                $query .= " AND s.timestamp >= $startTime";
                break;
            case 'thisWeek':
                $startTime = strtotime('this week midnight');
                $query .= " AND s.timestamp >= $startTime";
                break;
            case 'thisMonth':
                $startTime = strtotime('first day of this month midnight');
                $query .= " AND s.timestamp >= $startTime";
                break;
        }
    }

    // Finish the subquery by grouping by user and difficulty
    $query .= " 
            GROUP BY u.user_id, u.username, hs.difficulty_level
        )
        
        SELECT 
            s.score_id,
            s.user_id,
            s.score,
            s.timestamp,
            u.username,
            hs.word_length,
            hs.wrong_guesses,
            hs.remaining_tries,
            hs.difficulty_level,
            hs.time_spent,
            hs.word_category
        FROM 
            scores s
        JOIN 
            users u ON s.user_id = u.user_id
        JOIN 
            hangman_scores hs ON s.score_id = hs.score_id
        JOIN 
            games g ON s.game_id = g.game_id
        JOIN 
            BestScores bs ON s.user_id = bs.user_id 
                AND hs.difficulty_level = bs.difficulty_level 
                AND s.score = bs.max_score
        WHERE 
            g.game_code = 'hangman'
    ";

    // Add difficulty filter if not 'all'
    if ($difficulty !== 'all') {
        $difficultyLevel = 0;
        switch ($difficulty) {
            case 'easy':
                $difficultyLevel = 1;
                break;
            case 'medium':
                $difficultyLevel = 2;
                break;
            case 'hard':
                $difficultyLevel = 3;
                break;
            case 'expert':
                $difficultyLevel = 4;
                break;
        }
        
        if ($difficultyLevel > 0) {
            $query .= " AND hs.difficulty_level = $difficultyLevel";
        }
    }

    // Order by score descending
    $query .= " ORDER BY s.score DESC LIMIT 100";

    // Execute query
    $result = $conn->query($query);
    
    if (!$result) {
        throw new Exception("Database query error: " . $conn->error);
    }

    // Initialize empty array for leaderboard data
    $leaderboardData = [];

    // Counter for rank
    $rank = 1;

    // Fetch and format results
    while ($row = $result->fetch_assoc()) {
        // Konversi timestamp ke format tanggal dengan zona waktu Indonesia/Jakarta
        $timestamp = (int)$row['timestamp']; 
        if ($timestamp <= 0) {
            // Jika timestamp tidak valid, gunakan tanggal hari ini
            $date = date('M j, Y');
        } else {
            $date = date('M j, Y', $timestamp);
        }
        
        // Log timestamp untuk debugging
        file_put_contents($log_file, "Row timestamp value: " . $row['timestamp'] . ", Converted: $timestamp, Date: $date\n", FILE_APPEND);
        
        // Calculate time in minutes and seconds
        $minutes = floor($row['time_spent'] / 60);
        $seconds = $row['time_spent'] % 60;
        $timeFormatted = sprintf('%02d:%02d', $minutes, $seconds);
        
        // Get difficulty name
        $difficultyName = 'medium';
        switch ($row['difficulty_level']) {
            case 1:
                $difficultyName = 'easy';
                break;
            case 2:
                $difficultyName = 'medium';
                break;
            case 3:
                $difficultyName = 'hard';
                break;
            case 4:
                $difficultyName = 'expert';
                break;
        }
        
        // Format player data
        $playerData = [
            'rank' => $rank,
            'player' => [
                'name' => $row['username'],
                'avatar' => substr($row['username'], 0, 1), // First letter as avatar
            ],
            'score' => (int)$row['score'],
            'guesses' => (int)$row['wrong_guesses'],
            'time' => $timeFormatted,
            'difficulty' => $difficultyName,
            'date' => $date
        ];
        
        // Add to leaderboard array
        $leaderboardData[] = $playerData;
        
        // Increment rank
        $rank++;
    }
    
    // Log the number of results
    file_put_contents($log_file, "Found " . count($leaderboardData) . " leaderboard entries\n", FILE_APPEND);
    
    // Return success response with leaderboard data
    echo json_encode([
        'success' => true,
        'leaderboard' => $leaderboardData
    ]);
    
} catch (Exception $e) {
    // Log the error
    file_put_contents($log_file, "ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
    file_put_contents($log_file, "Query: " . $query . "\n", FILE_APPEND);
    
    // Return error response
    echo json_encode([
        'success' => false,
        'message' => 'Error loading leaderboard data: ' . $e->getMessage()
    ]);
}

// Close database connection
$conn->close();