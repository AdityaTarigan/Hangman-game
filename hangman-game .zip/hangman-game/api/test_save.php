<?php
// Simple test script for save_score.php
// Place this in the same folder as save_score.php

// Simulate POST data
$_SERVER['REQUEST_METHOD'] = 'POST';
$_POST = [
    'playerName' => 'TestPlayer',
    'score' => 850,
    'incorrect_guesses' => 2,
    'hints_used' => 1,
    'time_spent' => 60,
    'word_length' => 6,
    'difficulty' => 'medium'
];

// Include the save_score.php script
include 'save_score.php';
?>