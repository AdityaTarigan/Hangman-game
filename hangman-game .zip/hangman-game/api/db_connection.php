<?php
// Database connection parameters
$host = 'localhost';
$database = 'game_hub';
$user = 'root';
$password = ''; // Change this to your actual database password

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set character set
$conn->set_charset("utf8");
?>