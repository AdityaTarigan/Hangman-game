/**
 * Authentication integration for Hangman Game
 */
(function() {
    // Variables
    let isLoggedIn = false;
    let currentUser = null;
    
    console.log('Auth integration script loaded');
    
    // Wait for document to be ready
    $(document).ready(function() {
        console.log('Document ready, initializing auth...');
        
        // Check login status
        checkLoginStatus();
        
        // Add login/logout button to game interface
        addAuthButtons();
        

        
        // Setup event handlers
        setupEventHandlers();
        
        // Check for pending game data
        checkPendingGameData();
    });
    
    // Function to check if user is logged in
    function checkLoginStatus() {
        console.log('Checking login status...');
        
        $.ajax({
            url: 'api/check_auth.php',
            type: 'GET',
            dataType: 'json',
            cache: false, // Prevent caching
            success: function(response) {
                console.log('Auth check response:', response);
                if (response.success) {
                    isLoggedIn = true;
                    currentUser = response.user;
                    updateUIForLoggedInUser(currentUser);
                    console.log('User is logged in:', currentUser);
                } else {
                    isLoggedIn = false;
                    currentUser = null;
                    updateUIForGuestUser();
                    console.log('User is not logged in');
                }
            },
            error: function(xhr, status, error) {
                console.error('Auth check error:', {status, error, response: xhr.responseText});
                isLoggedIn = false;
                currentUser = null;
                updateUIForGuestUser();
            }
        });
    }
    
    // Add login/logout button to game interface - POSITIONED LEFT
    function addAuthButtons() {
        const headerContainer = $('.hanghead-fixed');
        
        // Create user auth container if it doesn't exist
        if ($('.user-auth-container').length === 0) {
            const authContainer = $('<div>', {
                class: 'user-auth-container',
                css: {
                    'position': 'absolute',
                    'top': '10px',
                    'left': '10px', // Position on LEFT side
                    'z-index': '1000',
                    'display': 'flex',
                    'align-items': 'center'
                }
            });
            
            // Add to the header
            headerContainer.append(authContainer);
            
            // Initial state - will be updated by checkLoginStatus()
            authContainer.html(`
                <div class="user-auth-section" style="display:flex; align-items:center; padding:8px 12px; background:rgba(255,255,255,0.15); backdrop-filter:blur(5px); border-radius:5px; box-shadow:0 3px 8px rgba(0,0,0,0.15); border:1px solid rgba(255,255,255,0.2);">
                    <div class="auth-loading">
                        <small style="color: white;">Checking login status...</small>
                    </div>
                </div>
            `);
        }
    }
    
    // Add leaderboard button
    function addLeaderboardButton() {
        const buttonContainer = $('.button-container');
        
        // Add leaderboard button if it doesn't exist
        if ($('a.leaderboard-link').length === 0) {
            const leaderboardBtn = $('<a>', {
                href: 'leaderboard.html',
                class: 'leaderboard-link btn btn-default btn-sm',
                css: {
                    'float': 'right',
                    'margin-right': '10px',
                    'background-color': 'rgba(255,255,255,0.9)',
                    'color': '#3c8dbc',
                    'border': '1px solid transparent',
                    'border-radius': '5px',
                    'padding': '5px 12px',
                    'font-size': '13px',
                    'font-weight': '600',
                    'transition': 'all 0.3s ease'
                },
                html: '<i class="glyphicon glyphicon-stats"></i> Leaderboard'
            });
            
            // Add to the container
            buttonContainer.prepend(leaderboardBtn);
        }
    }
    
    // Update UI for logged in user
    function updateUIForLoggedInUser(user) {
        $('.user-auth-container').html(`
            <div class="user-auth-section" style="display:flex; align-items:center; padding:8px 12px; background:rgba(255,255,255,0.15); backdrop-filter:blur(5px); border-radius:5px; box-shadow:0 3px 8px rgba(0,0,0,0.15); border:1px solid rgba(255,255,255,0.2);">
                <div class="user-greeting" style="color:#ffffff; font-weight:600; margin-right:15px; font-size:14px; display:flex; align-items:center;">
                    <div style="width:28px; height:28px; background:rgba(255,255,255,0.9); color:#3c8dbc; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:700; margin-right:8px; font-size:14px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
                        ${user.username.charAt(0).toUpperCase()}
                    </div>
                    Halo, <strong>${user.username}</strong>
                </div>
                <a href="api/logout.php" style="background:rgba(255,255,255,0.9); color:#3c8dbc; border:1px solid transparent; border-radius:5px; padding:5px 12px; font-size:13px; font-weight:600; transition:all 0.3s ease; text-decoration:none; display:inline-flex; align-items:center;">
                    <i class="glyphicon glyphicon-log-out" style="margin-right:5px;"></i> Logout
                </a>
            </div>
        `);
        
        // Update save score button text
        $('.save-score-btn').text('Simpan Skor');
    }
    
    // Update UI for guest user
    function updateUIForGuestUser() {
        $('.user-auth-container').html(`
            <div class="user-auth-section" style="display:flex; align-items:center; padding:8px 12px; background:rgba(255,255,255,0.15); backdrop-filter:blur(5px); border-radius:5px; box-shadow:0 3px 8px rgba(0,0,0,0.15); border:1px solid rgba(255,255,255,0.2);">
                <div style="display:flex; gap:10px;">
                    <a href="login.html" style="background:rgba(255,255,255,0.9); color:#3c8dbc; border:1px solid transparent; border-radius:5px; padding:5px 12px; font-size:13px; font-weight:600; transition:all 0.3s ease; text-decoration:none; display:inline-flex; align-items:center;">
                        <i class="glyphicon glyphicon-log-in" style="margin-right:5px;"></i> Login
                    </a>
                    <a href="register.html" style="background:rgba(40,167,69,0.9); color:white; border:1px solid transparent; border-radius:5px; padding:5px 12px; font-size:13px; font-weight:600; transition:all 0.3s ease; text-decoration:none; display:inline-flex; align-items:center;">
                        <i class="glyphicon glyphicon-user" style="margin-right:5px;"></i> Daftar
                    </a>
                </div>
            </div>
        `);
        
        // Update save score button text
        $('.save-score-btn').text('Simpan Skor (Login Diperlukan)');
    }
    
    // Setup event handlers for game completion
    function setupEventHandlers() {
        // When congratulatory modal is shown (game won)
        $('#congratulatory_message').on('show.bs.modal', function() {
            console.log('Congratulatory modal shown, isLoggedIn:', isLoggedIn);
            
            if (isLoggedIn) {
                // Update button for logged in users
                $('.save-score-btn').text('Simpan Skor').removeClass('btn-default').addClass('btn-primary');
            } else {
                // Update button for guests
                $('.save-score-btn').text('Simpan Skor (Login Diperlukan)').removeClass('btn-primary').addClass('btn-default');
            }
        });
        
        // Override save score button click
        $(document).on('click', '.save-score-btn', function(e) {
            e.preventDefault();
            console.log('Save score button clicked, isLoggedIn:', isLoggedIn);
            
            if (!isLoggedIn) {
                // If not logged in, store game data and redirect to login
                storeGameDataForLogin();
                
                // Direct redirect instead of confirm
                alert('Anda harus login untuk menyimpan skor. Anda akan dialihkan ke halaman login.');
                setTimeout(function() {
                    window.location.href = 'login.html';
                }, 500);
                return;
            }
            
            // User is logged in, proceed with saving score
            saveScore();
        });
    }
    
    // Store game data to be saved after login
    function storeGameDataForLogin() {
        // Get game data
        const gameData = {
            score: calculateCurrentScore(),
            incorrect_guesses: $('#letter-graveyard > div').length,
            time_spent: getGameTimeInSeconds(),
            word_length: $('.is-letter').length,
            difficulty: $('#difficulty').val() || 'medium',
            hints_used: parseInt($('#hint-used').text() || '0')
        };
        
        // Store in localStorage
        localStorage.setItem('pendingGameData', JSON.stringify(gameData));
        localStorage.setItem('loginRedirect', 'index.html');
        
        console.log('Game data stored for post-login save:', gameData);
    }
    
    // Save score to server
    function saveScore() {
        // Get game data
        const incorrectGuesses = $('#letter-graveyard > div').length;
        const timeSpent = getGameTimeInSeconds();
        const wordLength = $('.is-letter').length;
        const difficulty = $('#difficulty').val() || 'medium';
        const hintsUsed = parseInt($('#hint-used').text() || '0');
        const score = calculateCurrentScore();
        
        // Prepare data for AJAX
        const scoreData = {
            score: score,
            incorrect_guesses: incorrectGuesses,
            time_spent: timeSpent,
            word_length: wordLength,
            difficulty: difficulty,
            hints_used: hintsUsed
        };
        
        console.log('Saving score with data:', scoreData);
        
        // Send AJAX request
        $.ajax({
            url: 'api/save_score.php',
            type: 'POST',
            data: scoreData,
            dataType: 'json',
            timeout: 15000, // 15 second timeout
            success: function(response) {
                console.log('Save score response:', response);
                if (response.success) {
                    alert('Skor berhasil disimpan! Anda mendapatkan ' + score + ' poin.');
                    window.location.href = 'leaderboard.html?refresh=true';
                } else if (response.loginRequired) {
                    // Redirect to login
                    storeGameDataForLogin();
                    alert('Login diperlukan. Mengalihkan ke halaman login...');
                    setTimeout(function() {
                        window.location.href = 'login.html';
                    }, 500);
                } else {
                    alert('Error menyimpan skor: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error details:', {
                    status: status,
                    error: error,
                    responseText: xhr.responseText
                });
                
                if (xhr.responseText) {
                    try {
                        // Try to parse response if it exists
                        const response = JSON.parse(xhr.responseText);
                        if (response.loginRequired) {
                            storeGameDataForLogin();
                            alert('Login diperlukan untuk menyimpan skor. Anda akan dialihkan ke halaman login.');
                            setTimeout(function() {
                                window.location.href = 'login.html';
                            }, 500);
                            return;
                        }
                    } catch (e) {
                        console.error('Could not parse response:', e);
                    }
                }
                
                alert('Terjadi kesalahan saat menyimpan skor. Silakan coba lagi nanti.');
            },
            complete: function() {
                console.log('AJAX request completed');
            }
        });
    }
    
    // Helper function to get game time in seconds
    function getGameTimeInSeconds() {
        const timeDisplay = $('#game-timer').text();
        if (!timeDisplay) return 0;
        
        const timeParts = timeDisplay.split(':');
        return (parseInt(timeParts[0]) * 60) + parseInt(timeParts[1]);
    }
    
    // Helper function to calculate current score
    function calculateCurrentScore() {
        const incorrectGuesses = $('#letter-graveyard > div').length;
        const hintsUsed = parseInt($('#hint-used').text() || '0');
        const wordLength = $('.is-letter').length;
        const difficulty = $('#difficulty').val() || 'medium';
        const timeSpent = getGameTimeInSeconds();
        
        // Basic calculation (should match your game's scoring system)
        const baseScore = 1000;
        const incorrectPenalty = incorrectGuesses * 100;
        const hintPenalty = hintsUsed * 50;
        const wordBonus = wordLength * 20;
        const timeBonus = Math.max(0, 300 - Math.floor(timeSpent / 10));
        
        // Apply difficulty multiplier
        let multiplier = 1;
        switch (difficulty) {
            case 'easy': multiplier = 1; break;
            case 'medium': multiplier = 1.5; break;
            case 'hard': multiplier = 2; break;
            case 'expert': multiplier = 2.5; break;
        }
        
        // Calculate final score
        return Math.max(0, Math.floor((baseScore - incorrectPenalty - hintPenalty + wordBonus + timeBonus) * multiplier));
    }
    
    // Check for pending game data after login
    function checkPendingGameData() {
        const pendingDataString = localStorage.getItem('pendingGameData');
        if (pendingDataString) {
            try {
                const pendingData = JSON.parse(pendingDataString);
                console.log('Found pending game data:', pendingData);
                
                // If user is logged in, save the score after a short delay
                if (isLoggedIn) {
                    setTimeout(function() {
                        console.log('Attempting to save pending game data...');
                        
                        // Clear pending data first
                        localStorage.removeItem('pendingGameData');
                        
                        $.ajax({
                            url: 'api/save_score.php', 
                            type: 'POST',
                            data: pendingData,
                            dataType: 'json',
                            success: function(response) {
                                console.log('Pending save response:', response);
                                if (response.success) {
                                    alert('Skor berhasil disimpan! Anda mendapatkan ' + pendingData.score + ' poin.');
                                    window.location.href = 'leaderboard.html?refresh=true';
                                } else {
                                    alert('Error menyimpan skor: ' + response.message);
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('Error saving pending data:', {status, error, responseText: xhr.responseText});
                                alert('Terjadi kesalahan saat menyimpan skor tertunda.');
                            }
                        });
                    }, 1000); // Short delay to ensure login status is checked
                }
            } catch (e) {
                console.error('Error parsing pending game data:', e);
                localStorage.removeItem('pendingGameData');
            }
        }
    }
    
    // Make functions available globally
    window.GameAuth = {
        isLoggedIn: function() { return isLoggedIn; },
        currentUser: function() { return currentUser; },
        checkLoginStatus: checkLoginStatus,
        saveScore: saveScore
    };
})();