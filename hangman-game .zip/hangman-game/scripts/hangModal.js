$(document).ready(function() {
  $('#info').modal('show');
});