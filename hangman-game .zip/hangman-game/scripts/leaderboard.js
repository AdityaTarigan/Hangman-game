/**
 * Modern Hangman Leaderboard JavaScript
 * Enhanced version with improved visuals and animations
 */
 
(function() {
  // Initialize leaderboard on document load
  $(document).ready(function() {
    // Check for refresh parameter
    const urlParams = new URLSearchParams(window.location.search);
    const refreshParam = urlParams.get('refresh');
    
    // Add custom font sizing for better readability
    $('body').css('font-size', '16px');
    
    // Initialize animations for stat cards
    initializeAnimations();
    
    // Load game statistics
    loadGameStats();
    
    // Load initial leaderboard data
    const difficulty = $('#difficultyFilter').val() || 'all';
    const timeFilter = $('#timeFilter').val() || 'allTime';
    loadLeaderboardData(difficulty, timeFilter);
    
    // Setup event listeners for filters
    $('#difficultyFilter, #timeFilter').on('change', function() {
      const difficulty = $('#difficultyFilter').val();
      const timeFilter = $('#timeFilter').val();
      
      // Add animation to indicate filter change
      $(this).addClass('filter-changed');
      setTimeout(() => {
        $(this).removeClass('filter-changed');
      }, 500);
      
      loadLeaderboardData(difficulty, timeFilter);
    });
    
    // Setup refresh button if it doesn't exist yet
    if ($('#refreshData').length === 0) {
      const refreshBtn = $('<button id="refreshData" class="refresh-btn"><i class="fas fa-sync-alt"></i> Refresh Data</button>');
      
      refreshBtn.on('click', function() {
        $(this).find('i').addClass('fa-spin');
        loadGameStats();
        const difficulty = $('#difficultyFilter').val();
        const timeFilter = $('#timeFilter').val();
        loadLeaderboardData(difficulty, timeFilter, function() {
          setTimeout(function() {
            $('#refreshData i').removeClass('fa-spin');
            
            // Show success toast
            showToast('Leaderboard refreshed successfully!');
          }, 500);
        });
      });
      
      $('.filter-container').append(refreshBtn);
    }
    
    // Auto refresh if parameter exists
    if (refreshParam === 'true') {
      setTimeout(function() {
        $('#refreshData i').addClass('fa-spin');
        loadGameStats();
        const difficulty = $('#difficultyFilter').val();
        const timeFilter = $('#timeFilter').val();
        loadLeaderboardData(difficulty, timeFilter, function() {
          setTimeout(function() {
            $('#refreshData i').removeClass('fa-spin');
          }, 500);
        });
      }, 500);
    }
  });
  
  // Initialize animations
  function initializeAnimations() {
    // Add hover effects to the stats cards
    $('.stats-card').hover(
      function() {
        $(this).css({
          'transform': 'translateY(-8px)',
          'box-shadow': '0 12px 24px rgba(0, 0, 0, 0.12)'
        });
      },
      function() {
        $(this).css({
          'transform': 'translateY(0)',
          'box-shadow': '0 6px 12px rgba(0, 0, 0, 0.1)'
        });
      }
    );
  }
  
  // Function to load game statistics with animation
  function loadGameStats() {
    $.ajax({
      url: 'api/get_stats.php',
      type: 'GET',
      dataType: 'json',
      cache: false, // Avoid caching
      data: { _t: new Date().getTime() }, // Add timestamp to avoid cache
      success: function(response) {
        if (response.success) {
          // Animate the statistics
          animateValue('totalPlayers', 0, response.stats.totalPlayers, 1000);
          animateValue('gamesPlayed', 0, response.stats.gamesPlayed, 1000);
          animateValue('highestScore', 0, response.stats.highestScore, 1000);
          
          // Add a subtle highlight effect to stats cards
          $('.stats-card').addClass('stats-updated');
          setTimeout(() => {
            $('.stats-card').removeClass('stats-updated');
          }, 1000);
        } else {
          console.error('Error loading game statistics:', response.message);
          showToast('Failed to load statistics', 'error');
        }
      },
      error: function(xhr, status, error) {
        console.error('AJAX error loading game statistics:', error);
        console.error('Response:', xhr.responseText);
        showToast('Connection error', 'error');
      }
    });
  }
  
  // Animate number counter
  function animateValue(id, start, end, duration) {
    const obj = document.getElementById(id);
    const range = end - start;
    const minTimer = 50;
    let stepTime = Math.abs(Math.floor(duration / range));
    
    // Avoid division by zero and very small intervals
    stepTime = Math.max(stepTime, minTimer);
    
    // Clear existing interval if any
    if (window['interval_' + id]) {
      clearInterval(window['interval_' + id]);
    }
    
    const startTime = new Date().getTime();
    const endTime = startTime + duration;
    
    window['interval_' + id] = setInterval(function() {
      const now = new Date().getTime();
      const remaining = Math.max((endTime - now) / duration, 0);
      const value = Math.round(end - (remaining * range));
      obj.innerHTML = value.toLocaleString();
      if (value === end) {
        clearInterval(window['interval_' + id]);
      }
    }, stepTime);
  }
  
  // Function to load leaderboard data with filters
  function loadLeaderboardData(difficulty, timeFilter, callback) {
    // Show loading indicator with animation
    $('#leaderboardBody').html('<tr class="loading-row"><td colspan="7" class="text-center"><i class="fas fa-spinner fa-spin fa-2x"></i><div class="loading-text">Loading leaderboard data...</div></td></tr>');
    
    $.ajax({
      url: 'api/get_leaderboard.php',
      type: 'GET',
      data: {
        difficulty: difficulty,
        timeFilter: timeFilter,
        _t: new Date().getTime() // Add timestamp to avoid cache
      },
      dataType: 'json',
      cache: false, // Avoid caching
      success: function(response) {
        if (response.success) {
          // Delay slightly for better UX when data loads too fast
          setTimeout(() => {
            displayLeaderboard(response.leaderboard);
            
            // Show or hide the "no scores" message
            const noScoresMessage = document.getElementById('no-scores-message');
            if (response.leaderboard.length === 0) {
              $(noScoresMessage).fadeIn(300);
            } else {
              $(noScoresMessage).hide();
            }
            
            // Add row entrance animations
            $('.leaderboard-row').each((index, row) => {
              setTimeout(() => {
                $(row).addClass('row-entrance');
              }, index * 100);
            });
          }, 300);
          
          console.log("Leaderboard data loaded:", response.leaderboard);
        } else {
          console.error('Error loading leaderboard data:', response.message);
          $('#leaderboardBody').html('<tr><td colspan="7" class="text-center text-danger"><i class="fas fa-exclamation-circle"></i> Failed to load leaderboard data</td></tr>');
          $('#no-scores-message').fadeIn(300);
          showToast('Failed to load leaderboard data', 'error');
        }
        
        // Call callback if it exists
        if (typeof callback === 'function') {
          callback();
        }
      },
      error: function(xhr, status, error) {
        console.error('AJAX error loading leaderboard:', error);
        console.error('Response:', xhr.responseText);
        $('#leaderboardBody').html('<tr><td colspan="7" class="text-center text-danger"><i class="fas fa-exclamation-triangle"></i> Server connection error</td></tr>');
        $('#no-scores-message').fadeIn(300);
        showToast('Server connection error', 'error');
        
        // Call callback if it exists
        if (typeof callback === 'function') {
          callback();
        }
      }
    });
  }
  
  // Function to display leaderboard data
  function displayLeaderboard(leaderboardData) {
    const leaderboardBody = $('#leaderboardBody');
    
    // Clear existing data
    leaderboardBody.empty();
    
    // Populate the table with enhanced styling
    $.each(leaderboardData, function(index, item) {
      const row = $('<tr>').addClass('leaderboard-row');
      
      // Determine rank class for styling
      const rankClass = index < 3 ? 'rank-' + (index + 1) : 'rank-other';
      
      // Create the first letter avatar for player
      const playerInitial = item.player.name.charAt(0).toUpperCase();
      
      row.html(`
        <td>
          <div class="rank-badge ${rankClass}">${item.rank}</div>
        </td>
        <td class="player-cell">
          <div class="player-avatar">${playerInitial}</div>
          <span class="player-name">${escapeHtml(item.player.name)}</span>
        </td>
        <td>${item.score.toLocaleString()}</td>
        <td>${item.guesses}</td>
        <td>${item.time}</td>
        <td><span class="game-type ${item.difficulty.toLowerCase()}">${capitalize(item.difficulty)}</span></td>
        <td>${item.date}</td>
      `);
      
      leaderboardBody.append(row);
    });
    
    // Add hover effects to the rows
    $('.leaderboard-row').hover(
      function() {
        $(this).css({
          'transform': 'translateY(-4px)',
          'box-shadow': '0 4px 8px rgba(0, 0, 0, 0.05)',
          'background-color': 'rgba(60, 141, 188, 0.1)'
        });
      },
      function() {
        $(this).css({
          'transform': 'translateY(0)',
          'box-shadow': 'none',
          'background-color': 'transparent'
        });
      }
    );
  }
  
  // Function to show toast messages
  function showToast(message, type = 'success') {
    // Remove any existing toasts
    $('.toast-message').remove();
    
    // Create toast element
    const toast = $('<div class="toast-message"></div>');
    toast.addClass(type);
    
    // Set icon based on type
    let icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';
    if (type === 'info') icon = 'info-circle';
    
    toast.html(`<i class="fas fa-${icon}"></i> ${message}`);
    
    // Append to body
    $('body').append(toast);
    
    // Show with animation
    setTimeout(() => {
      toast.addClass('show');
      
      // Hide after delay
      setTimeout(() => {
        toast.removeClass('show');
        setTimeout(() => {
          toast.remove();
        }, 300);
      }, 3000);
    }, 100);
  }
  
  // Helper function to escape HTML
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
  
  // Helper function to capitalize first letter
  function capitalize(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }
  
  // Make functions available to global scope if needed
  window.HangmanLeaderboard = {
    loadGameStats: loadGameStats,
    loadLeaderboardData: loadLeaderboardData,
    refreshData: function() {
      $('#refreshData i').addClass('fa-spin');
      loadGameStats();
      const difficulty = $('#difficultyFilter').val() || 'all';
      const timeFilter = $('#timeFilter').val() || 'allTime';
      loadLeaderboardData(difficulty, timeFilter, function() {
        setTimeout(function() {
          $('#refreshData i').removeClass('fa-spin');
        }, 500);
      });
    }
  };
})();