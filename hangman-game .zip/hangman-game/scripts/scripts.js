// Game flow and timer functionality
(function() {
  // Variables
  let gameTimerInterval = null;
  let gameStartTime = 0;
  let gameElapsedTime = 0;
  let currentWordLength = 0;
  
  // Wait for document to be ready
  $(document).ready(function() {
    // Set up Start Game button
    $('#start-game-btn').on('click', function() {
      // Enable the game
      $('.game-container').removeClass('game-inactive');
      $('.letter-button').css('pointer-events', 'auto').css('opacity', '1');
      
      // Hide start button
      $(this).hide();
      
      // Start the timer
      startTimer();
      
      // Reset the game if needed
      if (typeof hangmanGraphic !== 'undefined' && typeof hangmanGraphic.reset === 'function') {
        hangmanGraphic.reset();
      }
    });
    
    // Handle difficulty change
    $('#difficulty').on('change', function() {
      // Show start button
      $('#start-game-btn').show();
      
      // Disable game
      $('.game-container').addClass('game-inactive');
      
      // Stop timer
      stopTimer();
      
      // Hide timer
      $('#game-timer-container').hide();
    });
    
    // Handle reset buttons
    $('.reset').on('click', function() {
      setTimeout(function() {
        // Show start button
        $('#start-game-btn').show();
        
        // Disable game
        $('.game-container').addClass('game-inactive');
        
        // Stop timer
        stopTimer();
        
        // Hide timer
        $('#game-timer-container').hide();
      }, 100);
    });
    
    // Add leaderboard button if not exists
    if (!$('.leaderboard-btn').length) {
      const leaderboardBtn = $('<button>', {
        type: 'button',
        class: 'btn btn-default pull-right leaderboard-btn',
        html: '<i class="glyphicon glyphicon-trophy"></i> Leaderboard',
        css: { 'margin-right': '10px' },
        click: function() {
          window.location.href = 'leaderboard.html';
        }
      });
      
      $('[data-target="#info"]').before(leaderboardBtn);
    }
    
    // Display How To Play modal on first load
    $('#info').modal('show');
  });
  
  // Start the timer
  function startTimer() {
    // Stop any existing timer
    stopTimer();
    
    // Show timer container
    $('#game-timer-container').fadeIn(300);
    
    // Set start time
    gameStartTime = new Date().getTime();
    gameElapsedTime = 0;
    
    // Update timer display initially
    updateTimerDisplay(0);
    
    // Update timer every second
    gameTimerInterval = setInterval(function() {
      const currentTime = new Date().getTime();
      const elapsed = Math.floor((currentTime - gameStartTime) / 1000);
      gameElapsedTime = elapsed;
      updateTimerDisplay(elapsed);
    }, 1000);
  }
  
  // Stop the timer
  function stopTimer() {
    if (gameTimerInterval) {
      clearInterval(gameTimerInterval);
      gameTimerInterval = null;
    }
  }
  
  // Update timer display
  function updateTimerDisplay(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    const formattedTime = 
      minutes.toString().padStart(2, '0') + ':' + 
      remainingSeconds.toString().padStart(2, '0');
    
    $('#game-timer').text(formattedTime);
  }
  
  // Format time for display
  function formatTime(seconds) {
    if (!seconds) return "00:00";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
  
  // Calculate score based on performance
  function calculateScore(incorrectGuesses, hintsUsed, wordLength, difficulty, timeElapsed) {
    const basePoints = 1000;
    const incorrectPenalty = 100;
    let difficultySettings = getCurrentDifficultySettings();
    const hintPenalty = difficultySettings.hintPenalty * 50;
    
    // Calculate word length bonus (longer words = more points)
    const wordLengthBonus = wordLength * 20;
    
    // Time bonus (faster time = more points) - max 500 points for speed
    // For words > 5 letters, give more time
    const expectedTime = wordLength > 5 ? wordLength * 10 : wordLength * 8;
    const timeBonus = Math.max(0, 500 - Math.floor((timeElapsed / expectedTime) * 100));
    
    // Difficulty multiplier
    let difficultyMultiplier = 1;
    switch(difficulty) {
      case 'easy': difficultyMultiplier = 1; break;
      case 'medium': difficultyMultiplier = 1.5; break;
      case 'hard': difficultyMultiplier = 2; break;
      case 'expert': difficultyMultiplier = 2.5; break;
    }
    
    // Calculate final score
    const score = Math.max(0, Math.floor((basePoints - (incorrectGuesses * incorrectPenalty) - (hintsUsed * hintPenalty) + wordLengthBonus + timeBonus) * difficultyMultiplier));
    return score;
  }
  
  // Save score function - MODIFIED to use authentication system
  function saveScore() {
    // Gunakan sistem autentikasi untuk menyimpan skor
    if (window.GameAuth && typeof window.GameAuth.saveScore === 'function') {
      window.GameAuth.saveScore();
    } else {
      console.error("Auth system not loaded");
      alert("Sistem autentikasi tidak dimuat dengan benar. Silakan muat ulang halaman.");
    }
  }
  
  // Original add score function - kept for backward compatibility
  function addScore(playerName, score, incorrectGuesses, hintsUsed, timeElapsed, wordLength, difficulty) {
    // Store current player for tracking
    localStorage.setItem('currentPlayer', playerName);
    
    // Debug log
    console.log("Attempting to save score:", {
      playerName: playerName,
      score: score,
      incorrect_guesses: incorrectGuesses,
      hints_used: hintsUsed,
      time_spent: timeElapsed,
      word_length: wordLength,
      difficulty: difficulty
    });
    
    // Send score to server via AJAX
    $.ajax({
      url: 'api/save_score.php',
      type: 'POST',
      data: {
        playerName: playerName,
        score: score,
        incorrect_guesses: incorrectGuesses,
        hints_used: hintsUsed,
        time_spent: timeElapsed,
        word_length: wordLength,
        difficulty: difficulty
      },
      dataType: 'json',
      success: function(response) {
        console.log('Server response:', response);
        if (response.success) {
          // Provide feedback to the player
          alert(`Score saved! You scored ${score} points in ${formatTime(timeElapsed)}.`);
          
          // Redirect to leaderboard page
          window.location.href = 'leaderboard.html';
        } else {
          console.error('Error saving score:', response.message);
          alert('Error saving score: ' + response.message);
        }
      },
      error: function(xhr, status, error) {
        console.error('AJAX error details:', {
          status: status,
          error: error,
          response: xhr.responseText
        });
        alert('Error connecting to server. Check console for details.');
      }
    });
  }

  // Create player name modal if needed
  function createPlayerNameModal() {
    if ($('#player_name_modal').length) {
      return; // Modal already exists
    }
    
    const modalHTML = `
    <div class="modal fade" id="player_name_modal" role="dialog" data-backdrop="static" data-keyboard="false">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Enter Your Name</h4>
          </div>
          <div class="modal-body">
            <form id="player-name-form">
              <div class="form-group">
                <label for="player-name">Your Name:</label>
                <input type="text" class="form-control" id="player-name" placeholder="Enter your name" 
                  maxlength="15" required value="${localStorage.getItem('currentPlayer') || ''}">
              </div>
              <div class="score-display">
                <p>Your Score:</p>
                <div class="score-value" id="player-score">0</div>
                <p>Time: <span id="player-time">00:00</span></p>
              </div>
              <div class="text-center">
                <button type="submit" class="btn btn-success">Save Score</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>`;
    
    $('body').append(modalHTML);
    
    // Add submit handler for the name form
    $('#player-name-form').on('submit', function(event) {
      event.preventDefault();
      const playerName = $('#player-name').val().trim();
      
      console.log("Form submitted with name:", playerName);
      
      if (playerName) {
        // Simpan ke localStorage sebagai backup
        localStorage.setItem('currentPlayer', playerName);
        
        // Tampilkan alert dengan data yang akan dikirim
        const incorrectGuesses = $('#letter-graveyard > div').length;
        const score = calculateScore(
          incorrectGuesses, 
          hintsUsed || 0, 
          currentWordLength || currentWord.length, 
          currentDifficulty, 
          gameElapsedTime
        );
        
        alert(`Attempting to save: ${playerName}, Score: ${score}, Incorrect: ${incorrectGuesses}`);
        
        // Lakukan AJAX call
        $.ajax({
          url: 'api/save_score.php',
          type: 'POST',
          data: {
            playerName: playerName,
            score: score,
            incorrect_guesses: incorrectGuesses,
            hints_used: hintsUsed || 0,
            time_spent: gameElapsedTime,
            word_length: currentWordLength || currentWord.length,
            difficulty: currentDifficulty
          },
          dataType: 'json',
          success: function(response) {
            alert("Score saved successfully: " + JSON.stringify(response));
            window.location.href = 'leaderboard.html';
          },
          error: function(xhr, status, error) {
            alert("Error saving score: " + xhr.responseText);
          }
        });
      }
    });
  }
  
  // Add score display and save button to congratulatory message
  function updateCongratulatoryMessage() {
    // Calculate score
    const incorrectGuesses = $('#letter-graveyard > div').length;
    const score = calculateScore(
      incorrectGuesses, 
      hintsUsed || 0, 
      currentWordLength || currentWord.length, 
      currentDifficulty, 
      gameElapsedTime
    );
    
    console.log("Updating congratulatory message, score:", score);
    
    // Add score display to congratulatory modal if not already there
    if (!$('#congratulatory_message .score-display').length) {
      const scoreHtml = `
        <div class="score-display">
          <p>Skor Anda:</p>
          <div class="score-value">${score.toLocaleString()}</div>
          <p>Waktu: ${formatTime(gameElapsedTime)}</p>
        </div>
        <button class="btn btn-primary save-score-btn">Simpan ke Leaderboard</button>
      `;
      $('#congratulatory_message .modal-body .text-center').append(scoreHtml);
      
      // Add click handler for save score button
      $('.save-score-btn').off('click').on('click', function() {
        // Log that button was clicked
        console.log("Save score button clicked");
        
        // Use the new save score function
        saveScore();
      });
    } else {
      $('#congratulatory_message .score-value').text(score.toLocaleString());
    }
  }
  
  // Hook into win/lose functions
  const originalWin = window.displayCongratulatoryMessageOnWin;
  if (typeof originalWin === 'function') {
    window.displayCongratulatoryMessageOnWin = function() {
      stopTimer();
      $('#start-game-btn').show();
      $('.game-container').addClass('game-inactive');
      const result = originalWin.apply(this, arguments);
      updateCongratulatoryMessage();
      return result;
    };
  }
  
  const originalLose = window.displayGameOverMessageOnLose;
  if (typeof originalLose === 'function') {
    window.displayGameOverMessageOnLose = function() {
      stopTimer();
      $('#start-game-btn').show();
      $('.game-container').addClass('game-inactive');
      return originalLose.apply(this, arguments);
    };
  }
  
  // Add stylesheet for score display and leaderboard button
  function addLeaderboardStyles() {
    const styles = `
      .score-display {
        margin: 15px 0;
        padding: 10px;
        background-color: #f8f9fa;
        border-radius: 8px;
        text-align: center;
        border: 1px dashed #3c8dbc;
      }
      .score-value {
        font-size: 28px;
        font-weight: bold;
        color: #28a745;
        margin-bottom: 5px;
      }
      .leaderboard-btn {
        margin-right: 10px;
        background-color: #fff;
        color: #3c8dbc;
        border: 2px solid #3c8dbc;
        transition: all 0.3s ease;
      }
      .leaderboard-btn:hover {
        background-color: #3c8dbc;
        color: white;
      }
      .save-score-btn {
        margin-top: 10px;
        background-color: #3c8dbc;
        color: white;
      }
      .user-auth-container {
        margin-bottom: 15px;
        display: flex;
        justify-content: flex-end;
        align-items: center;
      }
      .user-welcome {
        margin-right: 10px;
      }
    `;
    
    if (!$('#leaderboard-styles').length) {
      $('<style id="leaderboard-styles"></style>').text(styles).appendTo('head');
    }
  }
  
  // Initialize necessary styles
  addLeaderboardStyles();
  
  // Store current word length when word is set
  const originalSetWordToBeGuessed = window.setWordToBeGuessed;
  if (typeof originalSetWordToBeGuessed === 'function') {
    window.setWordToBeGuessed = function() {
      const result = originalSetWordToBeGuessed.apply(this, arguments);
      if (typeof currentWordFull !== 'undefined') {
        currentWordLength = currentWordFull.length;
      }
      return result;
    };
  }
})();

// Self invoking function hides currentWord from the console
(function() {
  /*
   * Pick from alphabet keypad. Returns the letter chosen.
   */
  $("#alphabet-keypad").on("click", ".letter-button", pickLetter);

  function pickLetter() {
    var letterPicked = $(this);

    letterPicked
      .removeClass("letter-button")
      .addClass("letter-disabled");

    letterPicked = letterPicked.html();
    handlePickedLetter(letterPicked);
  }

  function handlePickedLetter(letterPicked) {
    var resultMatches = [];
    var ind = currentWord.indexOf(letterPicked);

    // if letterPicked matches one or more letters in the current word
    // push all instances of that letter to resultMatches
    while (ind !== -1) {
      resultMatches.push(ind);
      ind = currentWord.indexOf(letterPicked, ind + 1);
    }

    //if resultMatches is greater than 0 proceed to place them in the dom
    if (resultMatches.length > 0) {
      var letterBlocks = document.getElementsByClassName("is-letter");
      resultMatches.map(function(num) {

        var domElem = document.createElement("span");
        domElem.innerHTML = currentWordFull[num].toUpperCase();
        letterBlocks[num].appendChild(domElem);
        displayCongratulatoryMessageOnWin();

      });
    //if letterBlock is not greater than 0 put the letter in the graveyard
    } else {
      var domElem = document.createElement("div");
      domElem.className = "grave-letter";
      domElem.innerHTML = letterPicked;
      document.getElementById("letter-graveyard").appendChild(domElem);
      hangmanGraphic.addBodyPart();
      displayGameOverMessageOnLose();
    }
  }

  function displayCongratulatoryMessageOnWin(){
    var correctlyGuessedLettersCount = $(".is-letter > span").length;
    if (correctlyGuessedLettersCount === currentWord.length) {
      $("#congratulatory_message").modal('show');
    }
  }

  function displayGameOverMessageOnLose() {
    var incorrectlyGuessedLettersCount = $("#letter-graveyard > div").length;
    //If number of letters guessed is equal to maxParts
    if (incorrectlyGuessedLettersCount === 7 ) {
      $("#gameover_message").modal('show');
      var gameOverMessage = "Uh oh. You took too many tries to guess the word. The correct word is - '" + currentWord + "'. Better luck next time.";
      $(".lead").text(gameOverMessage);
    }
  }

  /*
   * Hangman graphic with methods addBodyPart() and reset()
   */
  var hangmanGraphic = function () {
    var bodyParts = 0,
        maxParts = 7;
    return {
      addBodyPart : function () {
        if (bodyParts < maxParts) {
          ++bodyParts;
          $("#hangman-frame" + bodyParts).css("opacity", 1);
        }
      },

      reset : function () {
        $(".hangman-frames").css("opacity", 0);
        $("#hangman-frame0").css("opacity", 1);
        bodyParts = 0;
        resetAlphabetKeypad();
        removeGraveyardLetters();
        removeCorrectlyGuessedLetters();
        removeFillInTheBlanksAroundOldWord();
        setWordToBeGuessed();
        resetHint();
      }
    };
  }();

  // Next 2 lines will be refactored into interface for
  //   losing a life and reseting the game
  $(".reset").on("click", hangmanGraphic.reset);

  function resetAlphabetKeypad(){
    $("#alphabet-keypad > .letter-disabled").each(function(index, element){
      $(element).removeClass().addClass('letter-button');
    });
  }

  function removeGraveyardLetters(){
    $('#letter-graveyard > div').each(function(index, element){
      $(element).remove();
    });
  }

  function removeCorrectlyGuessedLetters(){
    $('#word-to-guess').each(function(index, element){
      $(element).children().html('');
    });
  }

  function removeFillInTheBlanksAroundOldWord(){
    $("#word-to-guess").html('');
  }

  /* NEW ADDITION: Word hints system */
  // Petunjuk dalam Bahasa Indonesia
var hints = {
  // Tempat terkenal
  "gedungsate": "Bangunan ikonik di Bandung yang menjadi kantor gubernur",
  "tangkubanperahu": "Gunung berapi terkenal di utara Bandung berbentuk seperti perahu terbalik",
  "kawahputih": "Danau kawah belerang dengan air berwarna biru kehijauan",
  "telagawarna": "Danau berwarna-warni di daerah Puncak",
  "cihampelas": "Jalan belanja terkenal untuk jeans dan fashion",
  "braga": "Jalan bersejarah dari masa kolonial Belanda",
  "lembang": "Kota dataran tinggi di utara Bandung terkenal dengan produk susu",
  "dago": "Daerah populer dengan kafe dan tempat wisata",
  "ciwidey": "Daerah dengan wisata alam seperti Kawah Putih",
  "maribaya": "Taman alam dengan air terjun dan jembatan gantung",
  
  // Makanan dan kuliner
  "surabi": "Kue tradisional yang sering disajikan dengan gula merah cair",
  "batagor": "Pangsit goreng yang terbuat dari ikan dan tapioka",
  "colenak": "Singkong fermentasi dengan saus gula dan kelapa",
  "cilok": "Bola-bola kenyal dari tepung tapioka dengan saus kacang",
  "cuanki": "Sup panas dengan bakso ikan dan mie",
  "karedok": "Salad sayuran mentah dengan saus kacang",
  "bandrek": "Minuman jahe panas dengan rempah-rempah",
  "comro": "Singkong goreng dengan isian oncom",
  "cimol": "Bola-bola kenyal dari tepung tapioka, biasanya digoreng",
  "gehu": "Tahu berisi sayuran",
  "miecakka": "Mie dengan saus ubi jalar yang gurih",
  "kupat": "Ketupat, nasi yang dibungkus daun kelapa",
  "tahu": "Makanan dari kedelai yang sering disajikan sebagai camilan",
  "peuyeum": "Tape singkong, makanan tradisional Sunda",
  "asinan": "Buah dan sayuran yang diasinkan dengan saus asam",
  
  // Universitas dan pendidikan
  "itb": "Universitas teknik tertua dan paling bergengsi di Indonesia",
  "unpad": "Universitas negeri besar dengan fakultas kedokteran dan hukum terkemuka",
  "upi": "Universitas yang fokus pada pendidikan dan pengajaran",
  "maranatha": "Universitas Kristen terkenal dengan kedokteran dan seni",
  "widyatama": "Universitas swasta di Bandung timur",
  "parahyangan": "Universitas Katolik terkenal dengan fakultas hukum dan ekonomi",
  "pasundan": "Universitas swasta yang dinamai dari wilayah Sunda",
  "telkom": "Universitas yang mengkhususkan pada telekomunikasi dan teknologi",
  
  // Budaya dan seni
  "angklung": "Alat musik tradisional terbuat dari bambu",
  "wayang": "Pertunjukan teater boneka tradisional",
  "kecapi": "Alat musik petik tradisional Sunda",
  "batik": "Teknik dekorasi kain tradisional",
  "saung": "Pondok atau gazebo tradisional Sunda",
  "sunda": "Suku asli Jawa Barat",
  "jaipong": "Bentuk tarian tradisional Sunda",
  "sisingaan": "Tarian singa tradisional dari daerah Subang",
  
  // Belanja dan mode
  "cibaduyut": "Daerah terkenal dengan sepatu kulit buatan tangan",
  "parisvan": "Area belanja populer dengan factory outlet",
  "pasteur": "Jalan dengan banyak toko fashion",
  "sukajadi": "Distrik dengan pusat perbelanjaan dan hotel",
  "factory": "Jenis toko baju diskon yang terkenal di Bandung",
  "outlet": "Jenis toko pakaian yang umum di Bandung",
  "distro": "Pengecer fashion independen yang berasal dari Bandung",
  "jeans": "Celana denim, produk populer di Cihampelas",
  "denim": "Kain yang umum dijual di distrik fashion Bandung",
  
  // Alam dan taman
  "tahura": "Singkatan Taman Hutan Raya",
  "juanda": "Taman hutan yang dinamai pahlawan nasional",
  "patenggang": "Danau dikelilingi perkebunan teh",
  "ciater": "Daerah terkenal dengan pemandian air panas",
  "rancaupas": "Area wisata alam dengan taman rusa",
  "situ": "Kata Sunda untuk danau",
  "taman": "Area publik dengan tanaman dan fasilitas rekreasi",
  "hutan": "Area luas dengan pepohonan dan tumbuhan",
  "gunung": "Bentuk alam berupa bukit yang sangat besar",
  "danau": "Cekungan besar di daratan yang berisi air",
  
  // Referensi ikonik lainnya
  "pasupati": "Jembatan ikonik yang menghubungkan Bandung utara dan selatan",
  "transmetro": "Sistem transportasi umum di Bandung",
  "panghegar": "Hotel bersejarah di pusat kota Bandung",
  "savoy": "Hotel bersejarah bergaya art deco di Bandung",
  "gasibu": "Lapangan publik dekat Gedung Sate",
  "gedungmerdeka": "Bangunan tempat Konferensi Asia-Afrika diadakan",
  "asiaafrika": "Jalan bersejarah tempat konferensi terkenal diadakan",
  "saparua": "Pasar tradisional di Bandung",
  "superhero": "Taman petualangan luar ruangan di Bandung utara",
  "floatingmarket": "Atraksi wisata dengan pedagang di atas perahu"
};

  function getHint(word) {
    return hints[word.toLowerCase()] || "No hint available for this word";
  }

  function resetHint() {
    $("#hint-text").hide().text("");
    $("#hint-used").text("0");
    $("#hint-button").removeClass("disabled").prop("disabled", false);
    
    // Reset hint counters
    hintsUsed = 0;
    
    // Update based on current difficulty
    updateDifficultyDisplay();
  }

  // adding dictionary and word filter //
  var hangmanWords = [
    // Tempat terkenal
    "gedungsate", "tangkubanperahu", "kawahputih", "telagawarna", "cihampelas",
    "braga", "lembang", "dago", "ciwidey", "maribaya",
    
    // Makanan dan kuliner
    "surabi", "batagor", "colenak", "cilok", "cuanki",
    "karedok", "bandrek", "comro", "cimol", "gehu",
    "miecakka", "kupat", "tahu", "peuyeum", "asinan",
    
    // Universitas dan pendidikan
    "itb", "unpad", "upi", "maranatha", "widyatama",
    "parahyangan", "pasundan", "telkom",
    
    // Budaya dan seni
    "angklung", "wayang", "kecapi", "batik", "saung",
    "sunda", "jaipong", "sisingaan",
    
    // Belanja dan mode
    "cibaduyut", "parisvan", "pasteur", "cihampelas", "sukajadi",
    "factory", "outlet", "distro", "jeans", "denim",
    
    // Alam dan taman
    "tahura", "juanda", "patenggang", "ciater", "rancaupas",
    "situ", "taman", "hutan", "gunung", "danau",
    
    // Referensi ikonik lainnya
    "pasupati", "transmetro", "panghegar", "savoy", "gasibu",
    "gedungmerdeka", "asiaafrika", "saparua", "superhero", "floatingmarket"
  ];

  var easyArray = hangmanWords.filter(function(word){
    return word.length <= 4;
  });

  var mediumArray = hangmanWords; // All words

  var hardArray = hangmanWords.filter(function(word){
    return word.length > 4;
  });

  // Difficulty settings
  var difficultySettings = {
    easy: {
      wordArray: easyArray,
      maxHints: 3,
      hintPenalty: 0
    },
    medium: {
      wordArray: mediumArray,
      maxHints: 2,
      hintPenalty: 1
    },
    hard: {
      wordArray: hardArray,
      maxHints: 1,
      hintPenalty: 1
    },
    expert: {
      wordArray: hardArray,
      maxHints: 1,
      hintPenalty: 2
    }
  };

  // Default difficulty
  var currentDifficulty = "medium";

  function getCurrentDifficultySettings() {
    return difficultySettings[currentDifficulty];
  }

  // Handle difficulty change
  $(document).on("change", "#difficulty", function() {
    currentDifficulty = $(this).val();
    hangmanGraphic.reset();
    updateDifficultyDisplay();
  });

  function updateDifficultyDisplay() {
    var settings = getCurrentDifficultySettings();
    $("#hint-max").text(settings.maxHints);
    
    // Update visual indicator if it exists
    if ($(".difficulty-indicator").length) {
      $(".difficulty-indicator").removeClass("difficulty-easy difficulty-medium difficulty-hard difficulty-expert")
                               .addClass("difficulty-" + currentDifficulty);
    }
    
   // Update hint button state
   if (settings.maxHints === 0) {
    $("#hint-button").prop("disabled", true).addClass("disabled");
  } else {
    $("#hint-button").prop("disabled", false).removeClass("disabled");
  }
  
  // Reset hint counter
  hintsUsed = 0;
  $("#hint-used").text("0");
  $("#hint-text").hide();
}

function wordSelect(array) {
  var num = Math.floor(Math.random() * (array.length - 1));
  var word = array[num];
  return word;
}

function setWordToBeGuessed(){
  var settings = getCurrentDifficultySettings();
  currentWordFull = wordSelect(settings.wordArray);
  
  //set an all upper case version of the current word
  currentWord = currentWordFull.toUpperCase();
  //creates blocks in the DOM indicating where there are letters and spaces

  currentWord.split("").map(function(character) {
    var guessWordBlock = document.getElementById("word-to-guess");

    var domElem = document.createElement("div");

    if (character.match(/[a-z]/i)) {
      domElem.className = "character-block is-letter";
    } else {
      domElem.className = "character-block";
    }

    guessWordBlock.appendChild(domElem);
  });

  // Set the hint for the current word
  currentHint = getHint(currentWordFull);
  
  // Update hint availability based on difficulty
  hintPenalty = settings.hintPenalty;
  maxHints = settings.maxHints;
  
  // Update the max hints display
  $("#hint-max").text(maxHints);
}

// Initialize hint system
var currentHint;
var hintsUsed = 0;
var hintPenalty = 1; // How many wrong guesses a hint counts as
var maxHints = 2; // Default max hints

// Add hint button click handler
$(document).on("click", "#hint-button", function() {
  var settings = getCurrentDifficultySettings();
  
  // Check if hints are available
  if (hintsUsed >= settings.maxHints) {
    // Show message that no more hints are available
    $("#hint-text").show().text("No more hints available for this difficulty level!");
    return;
  }

  hintsUsed++;
  $("#hint-text").show().text(currentHint);
  $("#hint-used").text(hintsUsed);

  // Disable hint button if max hints reached
  if (hintsUsed >= settings.maxHints) {
    $("#hint-button").addClass("disabled").prop("disabled", true);
  }

  // Penalty for using hint
  if (settings.hintPenalty > 0) {
    for (var i = 0; i < settings.hintPenalty; i++) {
      hangmanGraphic.addBodyPart();
    }
    
    // Check for game over after penalty
    var incorrectlyGuessedLettersCount = $("#letter-graveyard > div").length;
    if (incorrectlyGuessedLettersCount + (hintsUsed * settings.hintPenalty) >= 7) {
      displayGameOverMessageOnLose();
    }
  }
});

var currentWordFull;
var currentWord;

setWordToBeGuessed();

// Create hint section when document is ready
$(document).ready(function() {
  // Create hint section if it doesn't exist
  if ($("#word-hint").length === 0) {
    var hintSection = `
      <div id="word-hint">
        <button id="hint-button" class="btn">Need a Hint?</button>
        <p id="hint-text"></p>
        <div class="hint-counter">
          <small>Hints used: <span id="hint-used">0</span>/<span id="hint-max">2</span></small>
        </div>
      </div>
    `;
    
    $("#word-to-guess").after(hintSection);
  }

  // Initialize difficulty display
  updateDifficultyDisplay();

  // Add difficulty indicator next to selector
  $("#difficulty").after('<span class="difficulty-indicator difficulty-medium"></span>');
});
})();

// Add leaderboard script for the leaderboard page
$(document).ready(function() {
// If on the leaderboard page
if ($('#leaderboardBody').length) {
  // Load game statistics
  loadLeaderboardStats();

  // Load initial leaderboard data with default filters
  const difficulty = $('#difficultyFilter').val() || 'all';
  const timeFilter = $('#timeFilter').val() || 'allTime';
  loadLeaderboardData(difficulty, timeFilter);

  // Setup event listeners for filters
  $('#difficultyFilter, #timeFilter').on('change', function() {
    const difficulty = $('#difficultyFilter').val();
    const timeFilter = $('#timeFilter').val();
    loadLeaderboardData(difficulty, timeFilter);
  });
}

// Function to load leaderboard stats
function loadLeaderboardStats() {
  $.ajax({
    url: 'api/get_stats.php',
    type: 'GET',
    dataType: 'json',
    success: function(response) {
      if (response.success) {
        $('#totalPlayers').text(response.stats.totalPlayers.toLocaleString());
        $('#gamesPlayed').text(response.stats.gamesPlayed.toLocaleString());
        $('#highestScore').text(response.stats.highestScore.toLocaleString());
      } else {
        console.error('Error loading stats:', response.message);
      }
    },
    error: function(xhr, status, error) {
      console.error('AJAX error loading stats:', error);
    }
  });
}

// Function to load leaderboard data
function loadLeaderboardData(difficulty, timeFilter) {
  $.ajax({
    url: 'api/get_leaderboard.php',
    type: 'GET',
    data: {
      difficulty: difficulty,
      timeFilter: timeFilter
    },
    dataType: 'json',
    success: function(response) {
      if (response.success) {
        displayLeaderboard(response.leaderboard);
        
        // Show or hide the "no scores" message
        if (response.leaderboard.length === 0) {
          $('#no-scores-message').show();
        } else {
          $('#no-scores-message').hide();
        }
      } else {
        console.error('Error loading leaderboard data:', response.message);
        $('#no-scores-message').show();
      }
    },
    error: function(xhr, status, error) {
      console.error('AJAX error loading leaderboard:', error);
      $('#no-scores-message').show();
    }
  });
}

// Function to display leaderboard data
function displayLeaderboard(leaderboardData) {
  const leaderboardBody = $('#leaderboardBody');

  // Clear existing data
  leaderboardBody.empty();

  // Populate the table
  $.each(leaderboardData, function(index, item) {
    const row = $('<tr>').addClass('leaderboard-row');
    
    const rankClass = index < 3 ? 'rank-' + (index + 1) : 'rank-other';
    
    row.html(`
      <td><div class="rank-badge ${rankClass}">${item.rank}</div></td>
      <td>
        <span class="player-avatar">${item.player.avatar}</span>
        ${escapeHtml(item.player.name)}
      </td>
      <td>${item.score.toLocaleString()}</td>
      <td>${item.guesses}</td>
      <td>${item.time}</td>
      <td><span class="game-type ${item.difficulty}">${capitalize(item.difficulty)}</span></td>
      <td>${item.date}</td>
    `);
    
    leaderboardBody.append(row);
  });
}

// Helper function to escape HTML
function escapeHtml(text) {
  if (!text) return '';
  return $('<div>').text(text).html();
}

// Helper function to capitalize first letter
function capitalize(string) {
  if (!string) return '';
  return string.charAt(0).toUpperCase() + string.slice(1);
}
});
