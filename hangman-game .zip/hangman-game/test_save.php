<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'api/db_connection.php';

// Create a test user
$testUsername = "TestUser_" . time();
$createdAt = time();

// Insert user
$sql = "INSERT INTO users (username, created_at) VALUES (?, ?)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "si", $testUsername, $createdAt);

if (mysqli_stmt_execute($stmt)) {
    $userId = mysqli_insert_id($conn);
    echo "<p>User created: ID = $userId, Username = $testUsername</p>";
} else {
    echo "<p>Error creating user: " . mysqli_error($conn) . "</p>";
    exit;
}

// Get game ID for hangman
$sql = "SELECT game_id FROM games WHERE game_code = 'hangman'";
$result = mysqli_query($conn, $sql);
if ($row = mysqli_fetch_assoc($result)) {
    $gameId = $row['game_id'];
    echo "<p>Found game: ID = $gameId</p>";
} else {
    echo "<p>Game 'hangman' not found. Try running the SQL to create it.</p>";
    exit;
}

// Insert score
$score = 500;
$timestamp = time();

$sql = "INSERT INTO scores (user_id, game_id, score, timestamp) VALUES (?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "iiis", $userId, $gameId, $score, $timestamp);

if (mysqli_stmt_execute($stmt)) {
    $scoreId = mysqli_insert_id($conn);
    echo "<p>Score saved: ID = $scoreId, Score = $score</p>";
} else {
    echo "<p>Error saving score: " . mysqli_error($conn) . "</p>";
    exit;
}

// Insert hangman specific data
$wordLength = 5;
$wrongGuesses = 3;
$remainingTries = 4;
$difficultyLevel = 2; // medium
$timeSpent = 120;
$wordCategory = "Test";

$sql = "INSERT INTO hangman_scores (score_id, word_length, wrong_guesses, remaining_tries, difficulty_level, time_spent, word_category) 
        VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "iiiiiis", $scoreId, $wordLength, $wrongGuesses, $remainingTries, $difficultyLevel, $timeSpent, $wordCategory);

if (mysqli_stmt_execute($stmt)) {
    $hangmanScoreId = mysqli_insert_id($conn);
    echo "<p>Hangman score details saved: ID = $hangmanScoreId</p>";
    echo "<p style='color:green;font-weight:bold;'>Test completed successfully!</p>";
} else {
    echo "<p>Error saving hangman score details: " . mysqli_error($conn) . "</p>";
}

// Check DB content
echo "<h3>All Users:</h3>";
$result = mysqli_query($conn, "SELECT * FROM users");
echo "<table border='1'><tr><th>ID</th><th>Username</th><th>Created</th></tr>";
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td>{$row['user_id']}</td><td>{$row['username']}</td><td>{$row['created_at']}</td></tr>";
}
echo "</table>";

echo "<h3>All Scores:</h3>";
$result = mysqli_query($conn, "SELECT s.*, u.username FROM scores s JOIN users u ON s.user_id = u.user_id");
echo "<table border='1'><tr><th>ID</th><th>User</th><th>Game ID</th><th>Score</th><th>Time</th></tr>";
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td>{$row['score_id']}</td><td>{$row['username']}</td><td>{$row['game_id']}</td><td>{$row['score']}</td><td>{$row['timestamp']}</td></tr>";
}
echo "</table>";

echo "<h3>All Hangman Scores:</h3>";
$result = mysqli_query($conn, "SELECT * FROM hangman_scores");
echo "<table border='1'><tr><th>ID</th><th>Score ID</th><th>Word Length</th><th>Wrong Guesses</th><th>Difficulty</th></tr>";
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td>{$row['hangman_score_id']}</td><td>{$row['score_id']}</td><td>{$row['word_length']}</td><td>{$row['wrong_guesses']}</td><td>{$row['difficulty_level']}</td></tr>";
}
echo "</table>";

mysqli_close($conn);
?>